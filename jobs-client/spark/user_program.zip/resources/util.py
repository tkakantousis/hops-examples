print("hello util")

def hello():
    print("hello def")